import React from 'react';
import { Sprout, Users, TrendingUp, ShoppingCart, Phone, ChevronRight, Tractor, LeafyGreen } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <header className="relative bg-green-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="lg:grid lg:grid-cols-12 lg:gap-8">
            <div className="sm:text-center md:max-w-2xl md:mx-auto lg:col-span-6 lg:text-left">
              <h1 className="text-4xl tracking-tight font-extrabold text-gray-900 sm:text-5xl md:text-6xl">
                <span className="block">Empowering Farmers,</span>
                <span className="block text-green-600">Connecting Consumers</span>
              </h1>
              <p className="mt-3 text-base text-gray-500 sm:mt-5 sm:text-xl lg:text-lg xl:text-xl">
                FarmYug is revolutionizing Punjab's agricultural sector by directly connecting farmers with consumers, ensuring fair prices and fresh produce for everyone.
              </p>
              <div className="mt-8 sm:max-w-lg sm:mx-auto sm:text-center lg:text-left">
                <button className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-green-600 hover:bg-green-700">
                  Get Started
                  <ChevronRight className="ml-2 h-5 w-5" />
                </button>
              </div>
            </div>
            <div className="mt-12 relative sm:max-w-lg sm:mx-auto lg:mt-0 lg:max-w-none lg:mx-0 lg:col-span-6 lg:flex lg:items-center">
              <div className="relative mx-auto w-full rounded-lg shadow-lg lg:max-w-md">
                <img
                  className="w-full rounded-lg"
                  src="https://images.unsplash.com/photo-1595074475099-699a5f10c035?auto=format&fit=crop&q=80&w=800"
                  alt="Punjab farmer in field"
                />
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Features Section */}
      <div className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
              Why Choose FarmYug?
            </h2>
          </div>

          <div className="mt-12 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
            <div className="relative bg-white p-6 rounded-lg shadow-sm border border-gray-200">
              <div className="text-center">
                <div className="inline-flex items-center justify-center h-12 w-12 rounded-md bg-green-100 text-green-600 mb-4">
                  <Tractor className="h-6 w-6" />
                </div>
                <h3 className="text-lg font-medium text-gray-900">Farmer Empowerment</h3>
                <p className="mt-2 text-base text-gray-500">
                  Direct market access and fair prices for farmers, eliminating middlemen.
                </p>
              </div>
            </div>

            <div className="relative bg-white p-6 rounded-lg shadow-sm border border-gray-200">
              <div className="text-center">
                <div className="inline-flex items-center justify-center h-12 w-12 rounded-md bg-green-100 text-green-600 mb-4">
                  <LeafyGreen className="h-6 w-6" />
                </div>
                <h3 className="text-lg font-medium text-gray-900">Fresh Produce</h3>
                <p className="mt-2 text-base text-gray-500">
                  Get farm-fresh products directly from local farmers to your table.
                </p>
              </div>
            </div>

            <div className="relative bg-white p-6 rounded-lg shadow-sm border border-gray-200">
              <div className="text-center">
                <div className="inline-flex items-center justify-center h-12 w-12 rounded-md bg-green-100 text-green-600 mb-4">
                  <TrendingUp className="h-6 w-6" />
                </div>
                <h3 className="text-lg font-medium text-gray-900">Transparent Pricing</h3>
                <p className="mt-2 text-base text-gray-500">
                  Fair and transparent pricing benefiting both farmers and consumers.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* How It Works Section */}
      <div className="bg-green-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
              How FarmYug Works
            </h2>
          </div>

          <div className="mt-12 grid grid-cols-1 gap-8 md:grid-cols-4">
            <div className="text-center">
              <div className="inline-flex items-center justify-center h-12 w-12 rounded-md bg-green-600 text-white mb-4">
                <Users className="h-6 w-6" />
              </div>
              <h3 className="text-lg font-medium text-gray-900">Register</h3>
              <p className="mt-2 text-sm text-gray-500">
                Sign up as a farmer or consumer
              </p>
            </div>

            <div className="text-center">
              <div className="inline-flex items-center justify-center h-12 w-12 rounded-md bg-green-600 text-white mb-4">
                <Sprout className="h-6 w-6" />
              </div>
              <h3 className="text-lg font-medium text-gray-900">List Products</h3>
              <p className="mt-2 text-sm text-gray-500">
                Farmers list their produce
              </p>
            </div>

            <div className="text-center">
              <div className="inline-flex items-center justify-center h-12 w-12 rounded-md bg-green-600 text-white mb-4">
                <ShoppingCart className="h-6 w-6" />
              </div>
              <h3 className="text-lg font-medium text-gray-900">Purchase</h3>
              <p className="mt-2 text-sm text-gray-500">
                Consumers buy directly
              </p>
            </div>

            <div className="text-center">
              <div className="inline-flex items-center justify-center h-12 w-12 rounded-md bg-green-600 text-white mb-4">
                <Phone className="h-6 w-6" />
              </div>
              <h3 className="text-lg font-medium text-gray-900">Delivery</h3>
              <p className="mt-2 text-sm text-gray-500">
                Get fresh produce delivered
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-green-600">
        <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:py-16 lg:px-8 lg:flex lg:items-center lg:justify-between">
          <h2 className="text-3xl font-extrabold tracking-tight text-white sm:text-4xl">
            <span className="block">Ready to get started?</span>
            <span className="block text-green-200">Join FarmYug today.</span>
          </h2>
          <div className="mt-8 flex lg:mt-0 lg:flex-shrink-0">
            <div className="inline-flex rounded-md shadow">
              <button className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-green-600 bg-white hover:bg-green-50">
                Register Now
              </button>
            </div>
            <div className="ml-3 inline-flex rounded-md shadow">
              <button className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white bg-green-700 hover:bg-green-800">
                Learn More
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-white">
        <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
          <div className="mt-8 border-t border-gray-200 pt-8 md:flex md:items-center md:justify-between">
            <div className="flex space-x-6 md:order-2">
              <a href="#" className="text-gray-400 hover:text-gray-500">
                About Us
              </a>
              <a href="#" className="text-gray-400 hover:text-gray-500">
                Contact
              </a>
              <a href="#" className="text-gray-400 hover:text-gray-500">
                Privacy Policy
              </a>
              <a href="#" className="text-gray-400 hover:text-gray-500">
                Terms
              </a>
            </div>
            <p className="mt-8 text-base text-gray-400 md:mt-0 md:order-1">
              © 2024 FarmYug. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;